<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>


</head>
<body>
 
<div class="container">
  <h5 align="center">Student Update List</h5>
  <div class="card">
    <div class="card-header bg-warning">Header</div>
    <div class="card-body">
    <div class="alert alert-success alert-dismissible" id="success" style="display:none;">
	  <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
	</div>
    <?php
  $i=1;
  foreach($data as $row)
  {
  ?>
  <div class="form-group">
    <label class="control-label col-sm-2" for="email">First Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" value="<?php echo $row->first_name; ?>" name="first_name" id="first_name" placeholder="Enter first_name">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Last Name:</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" value="<?php echo $row->last_name; ?>" name="last_name" id="last_name" placeholder="Enter last_name">
    </div>
  </div>
  <div class="form-group">
    <label class="control-label col-sm-2" for="pwd">Email</label>
    <div class="col-sm-10">
      <input type="text" class="form-control" value="<?php echo $row->email; ?>" id="email" name="email" placeholder="Enter password">
      <input type="hidden" class="form-control" value="<?php echo $row->id; ?>" id="id" name="id" placeholder="Enter password">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <button type="submit" name="submit" id="butsave" class="btn btn-primary">Submit</button>
    </div>
  </div>
</div> 
<?php } ?>
    <div class="card-footer bg-warning"> <div class="card-header bg-warning "><button type="button" id="update"  class="btn btn-danger btn-sm">+ Back</button></div>
  </div>
</div>

</body>
</html>
<script>
    $(document).ready(function() {
	$('#butsave').on('click', function() {
		var first_name = $('#first_name').val();
		var last_name = $('#last_name').val();
		var email = $('#email').val();
        var id = $('#id').val();
		
		if(first_name!="" && last_name!="" && email!="" && id!="" ){
			
			$.ajax({
				url: "<?php echo base_url() . 'Update/saveupdatedata'; ?>",
				type: "POST",
				data: {
					first_name: first_name,
					last_name: last_name,
					email: email,
                    id :id,
				
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$("#butsave").removeAttr("disabled");
						$('#fupForm').find('input:text').val('');
						$("#success").show();
						$('#success').html('Data added successfully !'); 						
					}
					else if(dataResult.statusCode==201){
					   alert("Error occured !");
					}
					
				}
			});
		}
		else{
			alert('Please fill all the field !');
		}
	});
});
$(document).ready(function(){  
      $('#update').click(function(){
      window.location ='<?php echo base_url() . 'Welcome/index'; ?>'
      });    
      });  

</script>

