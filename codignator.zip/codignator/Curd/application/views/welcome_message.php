<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
  <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
</head>
<body>
 
<div class="container">
  <h5 align="center">Student details</h5>
  <div class="card">
    <div class="card-header bg-warning "><button type="button" id="update"  class="btn btn-primary btn-sm">+ Add Student</button>
        
    </div>
    <div class="card-body"><table id="user_data" border="2px" class="display" style="width:100%">
        <thead>
            <tr>
                <th>first_name</th>
                <th>last_name</th>
                <th>Email</th>
                <th>Edit</th>
                <th>Delete</th>
                
            </tr>
        </thead>
        <tbody>
            
           
        </tbody>
        <tfoot>
            <tr>
            <th>first_name</th>
                <th>last_name</th>
                <th>Email</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </tfoot>
    </table>
</div> 
    <div class="card-footer bg-warning">Footer</div>
  </div>
</div>


<script>
$(document).ready(function(){  
      var dataTable = $('#user_data').DataTable({  
           "processing":true,  
           "serverSide":true,  
           "order":[],  
           "ajax":{  
                url:"<?php echo base_url() . 'Welcome/fetch_user'; ?>",  
                type:"POST"  
           },  
           "columnDefs":[  
                {  
                     "targets":[0, 3, 4],  
                     "orderable":false,  
                },  
           ],  
      });  
 });  

 $(document).ready(function(){  
      $('#update').click(function(){
      window.location ='<?php echo base_url() . 'Update/index'; ?>'
      });    
      });  

	</script>
</body>
</html>
