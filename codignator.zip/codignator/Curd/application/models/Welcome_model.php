<?php
class Welcome_model extends CI_model
{

    var $table ="crud";
    var $select_column = array('id','first_name','last_name','email');
    var $order_column = array(null,'first_name','last_name','email',null);

    function make_query()
    {
        $this->db->select($this->select_column);
        $this->db->from($this->table);
        if(isset($_POST['search']['value']))
        {
            $this->db->like('first_name',$_POST['search']['value']);
            $this->db->or_like('last_name',$_POST['search']['value']);
        }
        if(isset($_POST['order']))
        {
            $this->db->order_by($this->order_column[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);  
        }
        else  
           {  
                $this->db->order_by('id', 'DESC');  
           }  
      }
      function make_datatables(){  
        $this->make_query();  
        if($_POST["length"] != -1)  
        {  
             $this->db->limit($_POST['length'], $_POST['start']);  
        }  
        $query = $this->db->get();  
        return $query->result();  
   }  
   function get_filtered_data(){  
        $this->make_query();  
        $query = $this->db->get();  
        return $query->num_rows();  
   }       
   function get_all_data()  
   {  
        $this->db->select("*");  
        $this->db->from($this->table);  
        return $this->db->count_all_results();  
   }  

   function displayrecordsById($id)
   {
    $query=$this->db->query("select * from crud where id='".$id."'");
	return $query->result();
   }
   function saverecords($first_name,$last_name,$email)
	{
		$query="INSERT INTO `crud`( `first_name`, `last_name`, `email`) 
		VALUES ('$first_name','$last_name','$email')";
		$this->db->query($query);
	}
    function updaterecords($id,$first_name,$last_name,$email)
	{
		$query="UPDATE `crud` 
		SET `first_name`='$first_name',
		`last_name`='$last_name',
		`email`='$email' WHERE id=$id";
		$this->db->query($query);
	}

    function deleterecords($id)
  {
    $this->db->where("id", $id);
    $this->db->delete("crud");
    return true;
  }
      
    }

?>