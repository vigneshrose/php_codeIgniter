<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Update extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url'); 
		$this->load->database();
		$this->load->model('Welcome_model');
	}
	public function index()
	{
		$this->load->view('Update');
		
	}

    public function savedata()
    {
        
			$first_name=$this->input->post('first_name');
			$last_name=$this->input->post('last_name');
			$email=$this->input->post('email');
			$this->Welcome_model->saverecords($first_name,$last_name,$email);	
			echo json_encode(array(
				"statusCode"=>200
			));
		
    }
    public function updatedata()
    {
        $id=$this->input->get('id');
        $result['data']=$this->Welcome_model->displayrecordsById($id);
	    $this->load->view('update_records',$result);
    }
    public function saveupdatedata()
    {
            $id=$this->input->post('id');
			$first_name=$this->input->post('first_name');
			$last_name=$this->input->post('last_name');
			$email=$this->input->post('email');
			$this->Welcome_model->updaterecords($id,$first_name,$last_name,$email);
			echo json_encode(array(
				"statusCode"=>200
			));
    }
    public function delete()
    {
        $id=$this->input->get('id');
        $response=$this->Welcome_model->deleterecords($id);
        if($response==true){
           // echo "Data deleted successfully !";
            redirect('Welcome/index');
        }
        else{
            echo "Error !";
        }
    }
	
   

   
}
