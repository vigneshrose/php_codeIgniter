<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/userguide3/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
		
	}
	function fetch_user(){  
		$this->load->model("Welcome_model");  
		$fetch_data = $this->Welcome_model->make_datatables();  
		$data = array();  
		foreach($fetch_data as $row)  
		{  
			 $sub_array = array();  
			 $sub_array[] = $row->first_name;  
			 $sub_array[] = $row->last_name;  
			 $sub_array[] = $row->email;
			 $sub_array[] = '<a class="btn btn-warning btn-sm" href="'.base_url('Update/updatedata?id='.$row->id).'" role="button">Update</a>';  
			 $sub_array[] = '<a class="btn btn-warning btn-sm" href="'.base_url('Update/delete?id='.$row->id).'" role="button">Delete</a>';  
			 $data[] = $sub_array;  
		}  
		$output = array(  
			 "draw"                    =>     intval($_POST["draw"]),  
			 "recordsTotal"          =>      $this->Welcome_model->get_all_data(),  
			 "recordsFiltered"     =>     $this->Welcome_model->get_filtered_data(),  
			 "data"                    =>     $data  
		);  
		echo json_encode($output);  
   }  
   
   

   
}
